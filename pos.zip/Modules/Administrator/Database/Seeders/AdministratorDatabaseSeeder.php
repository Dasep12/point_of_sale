<?php

namespace Modules\Administrator\Database\Seeders;

use Illuminate\Database\Seeder;

class AdministratorDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
