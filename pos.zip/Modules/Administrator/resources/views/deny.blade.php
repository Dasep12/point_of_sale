@extends('administrator::layouts.master')

@section('content')
<div class="row">
    <div class="col-md-12 col-sm-12  ">
        <div class="x_panel">

            <div class="x_content">
                <div class="row justify-content-center">
                    <h3 class="text-danger fs-italic"><i class="fa fa-info-circle"></i> Access Denied</h3>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection