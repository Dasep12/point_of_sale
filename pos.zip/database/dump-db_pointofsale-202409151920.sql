b3 NOT NULL,
  `name_item` varchar(100) CHARACTER SET utf8mb3 DEFAULT NULL,
  `categori_id` int(11) NOT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `merek` varchar(255) CHARACTER SET utf8mb3 DEFAULT NULL,
  `satuan_dasar` varchar(100) CHARACTER SET utf8mb3 DEFAULT NULL,
  `konversi_satuan` double DEFAULT NULL,
  `harga_pokok` double DEFAULT NULL,
  `harga_jual_member_1` double DEFAULT NULL,
  `harga_jual_member_2` double DEFAULT NULL,
  `harga_umum` double DEFAULT NULL,
  `stock` double DEFAULT NULL,
  `stock_minimum` double DEFAULT NULL,
  `tipe_item` varchar(100) CHARACTER SET utf8mb3 DEFAULT NULL,
  `serial` varchar(100) CHARACTER SET utf8mb3 DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `status_item` int(1) DEFAULT NULL,
  `remarks` varchar(255) CHARACTER SET utf8mb3 DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` varchar(100) CHARACTER SET utf8mb3 DEFAULT NULL,
  `updated_by` varchar(100) CHARACTER SET utf8mb3 DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tbl_mst_material_unique_1` (`barcode`),
  UNIQUE KEY `tbl_mst_material_unique` (`kode_item`),
  KEY `tbl_mst_material_tbl_mst_categories_FK` (`categori_id`),
  KEY `tbl_mst_material_tbl_mst_units_FK` (`unit_id`),
  KEY `tbl_mst_material_tbl_mst_rak_FK` (`location_id`),
  KEY `tbl_mst_material_tbl_mst_warehouse_FK` (`warehouse_id`),
  CONSTRAINT `tbl_mst_material_tbl_mst_categories_FK` FOREIGN KEY (`categori_id`) REFERENCES `tbl_mst_categories` (`id`),
  CONSTRAINT `tbl_mst_material_tbl_mst_rak_FK` FOREIGN KEY (`location_id`) REFERENCES `tbl_mst_rak` (`id`),
  CONSTRAINT `tbl_mst_material_tbl_mst_units_FK` FOREIGN KEY (`unit_id`) REFERENCES `tbl_mst_units` (`id`),
  CONSTRAINT `tbl_mst_material_tbl_mst_warehouse_FK` FOREIGN KEY (`warehouse_id`) REFERENCES `tbl_mst_warehouse` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_mst_member`
--

DROP TABLE IF EXISTS `tbl_mst_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_mst_member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `levelMember_id` int(11) NOT NULL,
  `kode_member` varchar(255) CHARACTER SET utf8mb3 NOT NULL,
  `status_member` int(1) DEFAULT NULL,
  `remarks` varchar(255) CHARACTER SET utf8mb3 DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `created_by` varchar(100) CHARACTER SET utf8mb3 DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` varchar(100) CHARACTER SET utf8mb3 DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_mst_member_tbl_mst_level_member_FK` (`levelMember_id`),
  CONSTRAINT `tbl_mst_member_tbl_mst_level_member_FK` FOREIGN KEY (`levelMember_id`) REFERENCES `tbl_mst_level_member` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_mst_pajak`
--

DROP TABLE IF EXISTS `tbl_mst_pajak`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_mst_pajak` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb3 DEFAULT NULL,
  `code_pajak` varchar(100) CHARACTER SET utf8mb3 DEFAULT NULL,
  `persentase` double DEFAULT NULL,
  `status_pajak` int(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` varchar(100) CHARACTER SET utf8mb3 DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` varchar(100) CHARACTER SET utf8mb3 DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_mst_rak`
--

DROP TABLE IF EXISTS `tbl_mst_rak`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_mst_rak` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `location` varchar(100) DEFAULT NU) NOT NULL AUTO_INCREMENT,
  `accessmenu_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `add` int(1) DEFAULT NULL,
  `edit` int(1) DEFAULT NULL,
  `delete` int(1) DEFAULT NULL,
  `showAll` int(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tbl_sys_accesmenu_unique` (`accessmenu_id`,`user_id`),
  KEY `tbl_sys_accesmenu_tbl_mst_users_FK` (`user_id`),
  CONSTRAINT `tbl_sys_accesmenu_tbl_mst_users_FK` FOREIGN KEY (`user_id`) REFERENCES `tbl_mst_users` (`id`),
  CONSTRAINT `tbl_sys_accesmenu_tbl_sys_roleaccessmenu_FK` FOREIGN KEY (`accessmenu_id`) REFERENCES `tbl_sys_roleaccessmenu` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=905 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_sys_menu`
--

DROP TABLE IF EXISTS `tbl_sys_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_sys_menu` (
  `Menu_id` varchar(100) NOT NULL,
  `MenuLevel` varchar(100) DEFAULT NULL,
  `MenuUrut` varchar(100) DEFAULT NULL,
  `LevelNumber` varchar(100) DEFAULT NULL,
  `ParentMenu` varchar(100) DEFAULT NULL,
  `MenuName` varchar(100) DEFAULT NULL,
  `MenuIcon` varchar(100) DEFAULT NULL,
  `MenuUrl` varchar(100) DEFAULT NULL,
  `StatusMenu` int(1) DEFAULT 0,
  PRIMARY KEY (`Menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_sys_roleaccessmenu`
--

DROP TABLE IF EXISTS `tbl_sys_roleaccessmenu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_sys_roleaccessmenu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) DEFAULT NULL,
  `menu_id` varchar(11) DEFAULT NULL,
  `enable_menu` float DEFAULT 1,
  `created_at` datetime DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tbl_sys_roleaccessmenu_unique` (`role_id`,`menu_id`),
  KEY `tbl_sys_roleaccessmenu_tbl_sys_menu_FK` (`menu_id`),
  CONSTRAINT `tbl_sys_roleaccessmenu_tbl_mst_role_FK` FOREIGN KEY (`role_id`) REFERENCES `tbl_mst_role` (`id`),
  CONSTRAINT `tbl_sys_roleaccessmenu_tbl_sys_menu_FK` FOREIGN KEY (`menu_id`) REFERENCES `tbl_sys_menu` (`Menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=249 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_trn_detail_beli`
--

DROP TABLE IF EXISTS `tbl_trn_detail_beli`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_trn_detail_beli` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `item_id` int(11) NOT NULL,
  `in_stock` double NOT NULL,
  `hpp` double DEFAULT NULL,
  `total_harga` double NOT NULL,
  `item_name` varchar(100) CHARACTER SET utf8mb3 DEFAULT NULL,
  `unit_id` varchar(100) CHARACTER SET utf8mb3 DEFAULT NULL,
  `unit_name` varchar(100) CHARACTER SET utf8mb3 DEFAULT NULL,
  `kode_item` varchar(100) CHARACTER SET utf8mb3 DEFAULT NULL,
  `merek` varchar(100) CHARACTER SET utf8mb3 DEFAULT NULL,
  `supplier_name` varchar(255) CHARACTER SET utf8mb3 DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `created_by` varchar(100) CHARACTER SET utf8mb3 DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` varchar(100) CHARACTER SET utf8mb3 DEFAULT NULL,
  `header_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_trn_instock_tbl_mst_material_FK` (`item_id`),
  KEY `tbl_trn_detail_instock_tbl_mst_header_trans_FK` (`header_id`),
  CONSTRAINT `tbl_trn_detail_instock_tbl_mst_header_trans_FK` FOREIGN KEY (`header_id`) REFERENCES `tbl_trn_header_trans` (`id`),
  CONSTRAINT `tbl_trn_instock_tbl_mst_material_FK` FOREIGN KEY (`item_id`) REFERENCES `tbl_mst_material` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_cli,
  `kode_item` tinyint NOT NULL,
  `merek` tinyint NOT NULL,
  `unit_code` tinyint NOT NULL,
  `stock_minimum` tinyint NOT NULL,
  `inStock` tinyint NOT NULL,
  `outStock` tinyint NOT NULL,
  `Stock` tinyint NOT NULL,
  `updated_at` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_sys_menu`
--

DROP TABLE IF EXISTS `vw_sys_menu`;
/*!50001 DROP VIEW IF EXISTS `vw_sys_menu`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vw_sys_menu` (
  `user_id` tinyint NOT NULL,
  `enable_menu` tinyint NOT NULL,
  `menu_id` tinyint NOT NULL,
  `role_id` tinyint NOT NULL,
  `MenuName` tinyint NOT NULL,
  `MenuLevel` tinyint NOT NULL,
  `MenuIcon` tinyint NOT NULL,
  `LevelNumber` tinyint NOT NULL,
  `ParentMenu` tinyint NOT NULL,
  `MenuUrl` tinyint NOT NULL,
  `add` tinyint NOT NULL,
  `edit` tinyint NOT NULL,
  `delete` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_topsales`
--

DROP TABLE IF EXISTS `vw_topsales`;
/*!50001 DROP VIEW IF EXISTS `vw_topsales`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vw_topsales` (
  `item_name` tinyint NOT NULL,
  `qty` tinyint NOT NULL,
  `total_out` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Dumping routines for database 'db_pointofsale'
--

--
-- Final view structure for view `vw_master_price`
--

/*!50001 DROP TABLE IF EXISTS `vw_master_price`*/;
/*!50001 DROP VIEW IF EXISTS `vw_master_price`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_master_price` AS select `a`.`id` AS `id`,`a`.`member_id` AS `member_id`,`a`.`material_id` AS `material_id`,`c`.`name_item` AS `name_item`,`c`.`kode_item` AS `kode_item`,`c`.`merek` AS `merek`,`d`.`unit_code` AS `unit_code`,`c`.`barcode` AS `barcode`,`a`.`harga_jual` AS `harga_jual`,`c`.`unit_id` AS `unit_id` from (((`tbl_mst_harga` `a` left join `tbl_mst_level_member` `b` on(`b`.`id` = `a`.`member_id`)) left join `tbl_mst_material` `c` on(`c`.`id` = `a`.`material_id`)) left join `tbl_mst_units` `d` on(`d`.`id` = `c`.`unit_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_stock_item`
--

/*!50001 DROP TABLE IF EXISTS `vw_stock_item`*/;
/*!50001 DROP VIEW IF EXISTS `vw_stock_item`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_stock_item` AS select `a`.`id` AS `id`,`a`.`name_item` AS `name_item`,`a`.`barcode` AS `barcode`,`a`.`kode_item` AS `kode_item`,`a`.`merek` AS `merek`,`b`.`unit_code` AS `unit_code`,`a`.`stock_minimum` AS `stock_minimum`,coalesce(`x`.`inStock`,0) AS `inStock`,coalesce(`y`.`outStock`,0) AS `outStock`,coalesce(`x`.`inStock`,0) - coalesce(`y`.`outStock`,0) AS `Stock`,coalesce(`x`.`date_in`,`y`.`date_out`) AS `updated_at` from (((`db_pointofsale`.`tbl_mst_material` `a` left join `db_pointofsale`.`tbl_mst_units` `b` on(`b`.`id` = `a`.`unit_id`)) left 