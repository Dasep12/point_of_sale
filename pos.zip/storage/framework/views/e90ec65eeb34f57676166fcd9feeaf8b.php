<!-- Bootstrap -->
<script src="<?php echo e(asset('assets/vendors/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- FastClick -->
<script src="<?php echo e(asset('assets/vendors/fastclick/lib/fastclick.js')); ?>"></script>
<!-- NProgress -->
<script src="<?php echo e(asset('assets/vendors/nprogress/nprogress.js')); ?>"></script>
<!-- jQuery custom content scroller -->
<script src="<?php echo e(asset('assets/vendors/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>

<!-- Select2 -->
<script src="<?php echo e(asset('assets/vendors/select2/dist/js/select2.full.min.js')); ?>"></script>


<!-- Custom Theme Scripts -->
<script src="<?php echo e(asset('assets/build/js/custom.min.js')); ?>"></script>


<script>
    // only number and decimal
    function isNumberKey(evt) {
        var charCode = (evt.which) ? evt.which : evt.keyCode;
        if (charCode != 46 && charCode > 31 &&
            (charCode < 48 || charCode > 57))
            return false;

        return true;
    }

    $(window).on('load', function() {
        // Hide the loader
        $('#fullPageLoader').fadeOut('slow', function() {

        });
    });
</script><?php /**PATH D:\BIT-PROJECTS\bit.wmsPHP\Modules/Administrator\resources/views/layouts/footer.blade.php ENDPATH**/ ?>