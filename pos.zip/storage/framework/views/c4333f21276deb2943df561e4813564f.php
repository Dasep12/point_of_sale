<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            border: 2px solid #000;
            left: -30px !important;
            position: relative;
        }



        td {
            vertical-align: top;
            border: 2px solid #AAA;
            margin: 20px;
            text-align: center;
            padding: 15px;
        }

        .barcode {
            margin-bottom: 10px;
        }
    </style>
</head>

<body>
    <table>
        <tr>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <td>
                <p for=""><?php echo e($product->name_item); ?></p>
                <!-- <?php echo DNS1D::getBarcodeHTML($product->barcode, 'C128', 1.3, 45); ?> -->
                <img src="data:image/png;base64,<?php echo e(DNS1D::getBarcodePNG($product->barcode, 'C128',2, 55)); ?>" alt="barcode" />
                <p for=""><?php echo e($product->barcode); ?></p>
            </td>
            <?php if(($index + 1) % 3 == 0): ?>
        </tr>
        <tr>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
    </table>
</body>

</html><?php /**PATH D:\BIT-PROJECTS\pos\Modules/Administrator\resources/views/material/partials/barcode.blade.php ENDPATH**/ ?>