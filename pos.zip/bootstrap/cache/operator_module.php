<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Operator\\App\\Providers\\OperatorServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Operator\\App\\Providers\\OperatorServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);