<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Administrator\\App\\Providers\\AdministratorServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Administrator\\App\\Providers\\AdministratorServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);