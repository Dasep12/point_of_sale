<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Customers\\App\\Providers\\CustomersServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Customers\\App\\Providers\\CustomersServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);